export const SET_ACCOUNT = 'SET_ACCOUNT'
export const SET_NAME = 'SET_NAME'
export const SET_AVATAR = 'SET_AVATAR'
export const SET_TOKEN = 'SET_TOKEN'